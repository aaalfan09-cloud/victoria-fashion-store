# License — HAVEN STAY Website Template

Copyright (c) Visualiin Studio. All rights reserved.

Upon purchase, you are granted a non-exclusive, non-transferable license to use this
template for **one (1) end project** (personal or client).

You MAY:
- Modify the code, text and design for your project.
- Use the template for a client's website, as one project per license.

You MAY NOT:
- Resell, redistribute, or share the template (original or modified) as a template,
  theme, or source code, free or paid.
- Claim the template as your own original product for resale.

## Images
Included images were generated with AI tools. They are licensed for use inside the
purchased website project only and may not be extracted for resale or redistribution.
Exclusive rights are not guaranteed.

## Disclaimer
The template is provided "as is", without warranty of any kind. The reservation form
is a demo and sends no data.
