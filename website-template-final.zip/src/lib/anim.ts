import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { Flip } from "gsap/Flip";
import Lenis from "lenis";

const hasCdnGsap = () =>
  typeof window !== "undefined" &&
  Boolean((window as any).gsap) &&
  Boolean((window as any).ScrollTrigger) &&
  Boolean((window as any).Flip);

/* Thin accessors for the CDN-loaded animation libraries, with bundled fallbacks. */
export const g = (): any => (hasCdnGsap() ? (window as any).gsap : gsap);
export const ST = (): any =>
  hasCdnGsap() ? (window as any).ScrollTrigger : ScrollTrigger;
export const FlipLib = (): any =>
  hasCdnGsap() ? (window as any).Flip : Flip;
export const LenisLib = (): any =>
  (typeof window !== "undefined" && (window as any).Lenis) || Lenis;

export const reduced = (): boolean =>
  typeof window !== "undefined" &&
  window.matchMedia("(prefers-reduced-motion: reduce)").matches;

export const isDesktop = (): boolean =>
  typeof window !== "undefined" &&
  window.matchMedia("(hover: hover) and (pointer: fine)").matches;

export const money = (n: number): string =>
  "$" + n.toLocaleString("en-US", { maximumFractionDigits: 0 });

export const scrollToId = (id: string) => {
  const el = document.getElementById(id);
  if (!el) return;
  const lenis = (window as any).__lenis;
  if (lenis && lenis.scrollTo) lenis.scrollTo(el, { offset: 0, duration: 1.2 });
  else el.scrollIntoView({ behavior: reduced() ? "auto" : "smooth" });
};
