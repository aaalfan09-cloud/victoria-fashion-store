import atelierPlate04 from "../assets/images/atelier_plate_04_1794512911574.jpg";
import atelierPlate05 from "../assets/images/atelier_plate_05_1794512912115.jpg";
import atelierPlate06 from "../assets/images/atelier_plate_06_1794512911384.jpg";

export type Category = "Outerwear" | "Dresses" | "Bags" | "Footwear";

export type Product = {
  id: string;
  no: string;
  name: string;
  material: string;
  price: number;
  category: Category;
  meta: string;
  note: string;
  image: string;
  hover: string;
  span: string;
  offset: string;
  ratio: string;
};

/* REPLACE WITH REAL PHOTOS — placeholder Unsplash editorial imagery */
const U = (id: string, w = 1200) =>
  `https://images.unsplash.com/${id}?w=${w}&q=80&auto=format&fit=crop`;

export const products: Product[] = [
  {
    id: "p01",
    no: "01",
    name: "Alma Wool Coat",
    material: "Double-faced Italian wool",
    price: 3480,
    category: "Outerwear",
    meta: "SS26 — Look 02",
    note: "Cut long and unlined so the shoulder falls where the body does. Fastened with a single horn button.",
    image: U("photo-1539109136881-3be0616acf4b"),
    hover: U("photo-1496747611176-843222e1e57c"),
    span: "md:col-span-6",
    offset: "md:mt-0",
    ratio: "aspect-[3/4]",
  },
  {
    id: "p02",
    no: "02",
    name: "Serre Slip Dress",
    material: "Sand-washed silk charmeuse",
    price: 1890,
    category: "Dresses",
    meta: "SS26 — Look 05",
    note: "A bias-cut column that moves a half-second after you do. Finished by hand at the hem.",
    image: U("photo-1595777457583-95e059d581b8"),
    hover: U("photo-1515886657613-9f3515b0c78f"),
    span: "md:col-span-5",
    offset: "md:mt-28",
    ratio: "aspect-[4/5]",
  },
  {
    id: "p03",
    no: "03",
    name: "Pivot Shoulder Bag",
    material: "Vegetable-tanned calf",
    price: 2450,
    category: "Bags",
    meta: "SS26 — Look 07",
    note: "One piece of leather, folded twice, closed with a brushed brass pin. It softens with the year.",
    image: U("photo-1584917865442-de89df76afd3"),
    hover: U("photo-1566150905458-1bf1fc113f0d"),
    span: "md:col-span-4",
    offset: "md:mt-0",
    ratio: "aspect-[1/1]",
  },
  {
    id: "p04",
    no: "04",
    name: "Lido Leather Mule",
    material: "Polished nappa, stacked heel",
    price: 1200,
    category: "Footwear",
    meta: "SS26 — Look 09",
    note: "A 55mm heel built on a hand-lasted sole. Quiet on marble, which is the point.",
    image: U("photo-1543163521-1bf539c55dd2"),
    hover: U("photo-1548036328-c9fa89d128fa"),
    span: "md:col-span-5",
    offset: "md:-mt-16",
    ratio: "aspect-[3/4]",
  },
  {
    id: "p05",
    no: "05",
    name: "Castel Trench",
    material: "Waxed cotton gabardine",
    price: 2980,
    category: "Outerwear",
    meta: "SS26 — Look 11",
    note: "Storm flap removed, belt kept. Dry rain gear for a city that pretends it never rains.",
    image: U("photo-1434389677669-e08b4cac3105"),
    hover: U("photo-1485968579580-b6d095142e6e"),
    span: "md:col-span-7",
    offset: "md:mt-24",
    ratio: "aspect-[4/5]",
  },
  {
    id: "p06",
    no: "06",
    name: "Noir Column Gown",
    material: "Wool crêpe, silk lining",
    price: 4800,
    category: "Dresses",
    meta: "SS26 — Look 14",
    note: "Two hundred and ten hours of atelier work. A back seam you will never see photographed.",
    image: U("photo-1529139574466-a303027c1d8b"),
    hover: U("photo-1533659124865-d6072dc035e1"),
    span: "md:col-span-5",
    offset: "md:mt-0",
    ratio: "aspect-[3/4]",
  },
  {
    id: "p07",
    no: "07",
    name: "Fermo Top Handle",
    material: "Grained box calf",
    price: 3200,
    category: "Bags",
    meta: "SS26 — Look 16",
    note: "Structured enough for an envelope, soft enough for a Tuesday. Edge-painted in oxblood.",
    image: U("photo-1441984904996-e0b6ba687e04"),
    hover: U("photo-1483985988355-763728e1935b"),
    span: "md:col-span-6",
    offset: "md:-mt-10",
    ratio: "aspect-[1/1]",
  },
  {
    id: "p08",
    no: "08",
    name: "Arno Knee Boot",
    material: "Suede calf, leather sole",
    price: 1950,
    category: "Footwear",
    meta: "SS26 — Look 18",
    note: "Shaft cut one centimetre below the knee so the leg reads longer. Sixteen fittings.",
    image: U("photo-1572804013309-59a88b7e92f1"),
    hover: U("photo-1469334031218-e382a71b716b"),
    span: "md:col-span-6",
    offset: "md:mt-20",
    ratio: "aspect-[4/5]",
  },
];

export const categories = [
  "All",
  "Outerwear",
  "Dresses",
  "Bags",
  "Footwear",
] as const;

export type RunwayLook = {
  no: string;
  title: string;
  src: string;
  productId: string;
};

/* REPLACE WITH REAL PHOTOS — runway strip */
export const runwayLooks: RunwayLook[] = [
  { no: "01", title: "Sand Tailoring", src: U("photo-1490481651871-ab68de25d43d"), productId: "p05" },
  { no: "02", title: "Oxblood Silk", src: U("photo-1539109136881-3be0616acf4b"), productId: "p01" },
  { no: "03", title: "Bone Coat", src: U("photo-1496747611176-843222e1e57c"), productId: "p04" },
  { no: "04", title: "Crêpe Column", src: U("photo-1529139574466-a303027c1d8b"), productId: "p06" },
  { no: "05", title: "Raw Hem", src: U("photo-1485968579580-b6d095142e6e"), productId: "p03" },
  { no: "06", title: "Second Skin", src: U("photo-1515886657613-9f3515b0c78f"), productId: "p02" },
  { no: "07", title: "Carried Light", src: U("photo-1483985988355-763728e1935b"), productId: "p07" },
  { no: "08", title: "Night Wool", src: U("photo-1533659124865-d6072dc035e1"), productId: "p06" },
  { no: "09", title: "Open Shoulder", src: U("photo-1512436991641-6745cdb1723f"), productId: "p02" },
  { no: "10", title: "Closing Look", src: U("photo-1469334031218-e382a71b716b"), productId: "p08" },
];

/* REPLACE WITH REAL PHOTOS — lookbook drag gallery */
export const lookbook = [
  { src: U("photo-1487222477894-8943e31ef7b2"), h: "h-[340px] md:h-[520px]", w: "w-[260px] md:w-[380px]", speed: 0.08, cap: "Florence, 06:40" },
  { src: U("photo-1550639525-c97d455acf70"), h: "h-[420px] md:h-[640px]", w: "w-[300px] md:w-[460px]", speed: 0.16, cap: "Look 04 — detail" },
  { src: U("photo-1524592094714-0f0654e20314"), h: "h-[300px] md:h-[440px]", w: "w-[240px] md:w-[340px]", speed: 0.05, cap: "Brass pin, hand-set" },
  { src: U("photo-1558769132-cb1aea458c5e"), h: "h-[400px] md:h-[600px]", w: "w-[290px] md:w-[420px]", speed: 0.2, cap: "Backstage, Via Maggio" },
  { src: U("photo-1502716119720-b23a93e5fe1b"), h: "h-[360px] md:h-[500px]", w: "w-[270px] md:w-[400px]", speed: 0.1, cap: "Wool, undyed" },
  { src: U("photo-1529626455594-4ff0802cfb7e"), h: "h-[440px] md:h-[660px]", w: "w-[300px] md:w-[470px]", speed: 0.14, cap: "Look 09 — exit" },
  { src: U("photo-1483118714900-540cf339fd46"), h: "h-[320px] md:h-[460px]", w: "w-[250px] md:w-[360px]", speed: 0.06, cap: "Last fitting" },
];

/* REPLACE WITH REAL PHOTOS — atelier split screen */
export const atelierImages = [
  U("photo-1556905055-8f358a7a47b2"),
  U("photo-1558618666-fcd25c85cd64"),
  U("photo-1551232864-3f0890e580d9"),
  atelierPlate04,
  atelierPlate05,
  atelierPlate06,
];

export const atelierAlts = [
  "Italian wool bolts selected near Florence for the SS26 collection",
  "Hand-finishing a tailored garment inside the Via Maggio workshop",
  "Natural light inside the Florentine atelier courtyard studio",
  "Master tailor measuring and hand-basting wool cloth at a wooden worktable",
  "Close-up of hand-stitched inner wool jacket seam and woven atelier label",
  "Neutral wool fabric rolls and silk thread spools arranged on studio shelves",
];
