import { useEffect, useRef, useState } from "react";
import { X } from "lucide-react";
import { g, reduced, scrollToId } from "../lib/anim";

const NAV = [
  { label: "Runway", id: "runway", no: "01" },
  { label: "Collection", id: "collection", no: "02" },
  { label: "Atelier", id: "atelier", no: "03" },
  { label: "Lookbook", id: "lookbook", no: "04" },
  { label: "Newsletter", id: "newsletter", no: "05" },
];

export default function Header({
  count,
  onBag,
  visible = true,
}: {
  count: number;
  onBag: () => void;
  visible?: boolean;
}) {
  const bar = useRef<HTMLDivElement>(null);
  const overlay = useRef<HTMLDivElement>(null);
  const wasOpen = useRef(false);
  const [open, setOpen] = useState(false);

  /* hide on scroll down, show on scroll up */
  useEffect(() => {
    const gs = g();
    let last = window.scrollY;
    let hidden = false;
    const onScroll = () => {
      const y = window.scrollY;
      const down = y > last && y > 140;
      last = y;
      if (open) return;
      if (down === hidden) return;
      hidden = down;
      if (gs && !reduced())
        gs.to(bar.current, {
          yPercent: down ? -140 : 0,
          duration: 0.8,
          ease: "expo.out",
        });
      else if (bar.current)
        bar.current.style.transform = down ? "translateY(-140%)" : "none";
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, [open]);

  /* lock body scroll and handle Escape key while menu is open */
  useEffect(() => {
    const lenis = (window as any).__lenis;
    if (open) {
      document.body.style.overflow = "hidden";
      if (lenis) lenis.stop();
    } else {
      document.body.style.overflow = "";
      if (lenis && !document.body.classList.contains("is-locked")) {
        lenis.start();
      }
    }

    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape" && open) setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open]);

  /* fullscreen menu reveal + smooth fade-out */
  useEffect(() => {
    const gs = g();
    const el = overlay.current;
    if (!el) return;
    if (!gs || reduced()) {
      el.style.display = open ? "block" : "none";
      el.style.opacity = open ? "1" : "0";
      el.style.clipPath = open ? "inset(0% 0% 0% 0%)" : "inset(0% 0% 100% 0%)";
      wasOpen.current = open;
      return;
    }

    const lines = el.querySelectorAll("[data-menu-line]");
    const metaRows = el.querySelectorAll("[data-menu-meta]");
    const overlayBar = el.querySelector("[data-overlay-header]");

    if (open) {
      wasOpen.current = true;
      const tl = gs.timeline();
      tl.set(el, { display: "block", opacity: 1 })
        .fromTo(
          el,
          { clipPath: "inset(0% 0% 100% 0%)" },
          { clipPath: "inset(0% 0% 0% 0%)", duration: 1, ease: "expo.out" }
        )
        .fromTo(
          overlayBar,
          { opacity: 0 },
          { opacity: 1, duration: 0.5, ease: "power3.out" },
          "-=0.75"
        )
        .fromTo(
          lines,
          { yPercent: 115 },
          { yPercent: 0, duration: 1.1, ease: "expo.out", stagger: 0.07 },
          "-=0.6"
        )
        .fromTo(
          metaRows,
          { opacity: 0, y: 16 },
          { opacity: 1, y: 0, duration: 0.9, ease: "power3.out", stagger: 0.08 },
          "-=0.7"
        );
      return () => {
        tl.kill();
      };
    }

    if (!wasOpen.current) return;
    wasOpen.current = false;

    const tl = gs.timeline();
    tl.to(el, {
      opacity: 0,
      duration: 0.45,
      ease: "power3.out",
    }).set(el, {
      display: "none",
      opacity: 1,
      clipPath: "inset(0% 0% 100% 0%)",
    });
    return () => {
      tl.kill();
    };
  }, [open]);

  const go = (e: React.MouseEvent, id: string) => {
    e.preventDefault();
    const wasMenuOpen = open;
    setOpen(false);
    window.setTimeout(() => scrollToId(id), wasMenuOpen ? 480 : 0);
  };

  return (
    <header
      data-jiro-section="header"
      data-jiro-label="Header"
      className="pointer-events-none fixed inset-x-0 top-0 z-[110]"
    >
      <div
        ref={bar}
        aria-hidden={!visible}
        className={`relative z-[104] mix-blend-difference transition-opacity duration-700 ease-out ${
          visible
            ? "pointer-events-auto opacity-100"
            : "pointer-events-none opacity-0"
        }`}
        style={{ willChange: "transform, opacity" }}
      >
        <div className="flex items-center justify-between px-5 py-5 md:px-10 md:py-7">
          <a
            href="#top"
            onClick={(e) => go(e, "top")}
            data-cursor="link"
            className="font-display text-xl leading-none tracking-[0.18em] text-bone md:text-2xl"
          >
            VICTORIA
          </a>

          <nav
            aria-label="Primary"
            className="hidden items-center gap-10 lg:flex"
          >
            {NAV.slice(0, 4).map((n) => (
              <a
                key={n.id}
                href={`#${n.id}`}
                onClick={(e) => go(e, n.id)}
                data-cursor="link"
                className="label text-bone/80 transition-colors duration-300 hover:text-bone"
              >
                {n.label}
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-5 md:gap-8">
            <button
              type="button"
              onClick={onBag}
              data-cursor="link"
              data-magnetic
              className="btn btn-ghost btn-sm"
            >
              Bag
              <span className="flex h-[18px] min-w-[18px] items-center justify-center rounded-full border border-current px-1 text-[10px] leading-none">
                {count}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setOpen((v) => !v)}
              aria-expanded={open}
              data-cursor="link"
              className="btn btn-ghost btn-sm"
            >
              {open ? "Close" : "Menu"}
            </button>
          </div>
        </div>
      </div>

      {/* fullscreen menu */}
      <div
        ref={overlay}
        aria-hidden={!open}
        className="pointer-events-auto fixed inset-0 z-[105] hidden bg-ink"
        style={{ clipPath: "inset(0% 0% 100% 0%)" }}
      >
        {/* overlay top header */}
        <div
          data-overlay-header
          className="pointer-events-auto fixed inset-x-0 top-0 z-[115] flex items-center justify-between bg-ink px-5 py-5 md:px-10 md:py-7"
        >
          <a
            href="#top"
            onClick={(e) => go(e, "top")}
            data-cursor="link"
            className="font-display text-xl leading-none tracking-[0.18em] text-bone md:text-2xl"
          >
            VICTORIA
          </a>

          <button
            type="button"
            onClick={() => setOpen(false)}
            aria-label="Close menu"
            data-cursor="link"
            className="btn btn-ghost btn-sm min-h-[44px] min-w-[44px]"
          >
            <span>Close</span>
            <X className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
          </button>
        </div>

        <div className="relative z-[106] flex h-full flex-col justify-between overflow-y-auto px-5 pb-8 pt-32 md:px-10 md:pb-12 md:pt-44">
          <nav aria-label="Overlay" className="flex flex-col">
            {NAV.map((n) => (
              <div key={n.id} className="overflow-hidden py-1 md:py-2">
                <a
                  href={`#${n.id}`}
                  data-menu-line
                  onClick={(e) => go(e, n.id)}
                  data-cursor="link"
                  className="group flex items-baseline gap-4 font-display text-[13vw] leading-[0.95] tracking-[-0.02em] text-bone transition-colors duration-500 hover:text-bone/55 md:gap-8 md:text-[7.5vw]"
                >
                  <span className="label shrink-0 tabular-nums leading-none text-bone/40">
                    {n.no}
                  </span>
                  <span className="leading-[0.95]">{n.label}</span>
                </a>
              </div>
            ))}
          </nav>

          <div className="mt-10 grid grid-cols-1 gap-6 border-t border-bone/15 pt-6 sm:grid-cols-3">
            <div data-menu-meta className="label text-bone/50">
              Via Maggio 41r
              <br />
              50125 Firenze, Italia
            </div>
            <div data-menu-meta className="label text-bone/50">
              clients@victoria.studio
              <br />
              +39 055 0000 00
            </div>
            <div data-menu-meta className="label text-bone/50 sm:text-right">
              Instagram — Journal
              <br />
              Press enquiries
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
