import { useEffect, useRef } from "react";
import { g, isDesktop, reduced } from "../lib/anim";

export default function Cursor() {
  const dot = useRef<HTMLDivElement>(null);
  const ring = useRef<HTMLDivElement>(null);
  const label = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    const gs = g();
    if (!gs || !isDesktop() || reduced()) return;
    document.body.classList.add("has-cursor");

    gs.set([dot.current, ring.current], { xPercent: -50, yPercent: -50 });
    const dx = gs.quickTo(dot.current, "x", { duration: 0.08, ease: "power3.out" });
    const dy = gs.quickTo(dot.current, "y", { duration: 0.08, ease: "power3.out" });
    const rx = gs.quickTo(ring.current, "x", { duration: 0.5, ease: "power3.out" });
    const ry = gs.quickTo(ring.current, "y", { duration: 0.5, ease: "power3.out" });

    let magnet: HTMLElement | null = null;

    const onMove = (e: MouseEvent) => {
      dx(e.clientX);
      dy(e.clientY);
      rx(e.clientX);
      ry(e.clientY);

      const t = e.target as HTMLElement | null;
      const mag = t?.closest?.("[data-magnetic]") as HTMLElement | null;
      if (mag) {
        if (magnet && magnet !== mag)
          gs.to(magnet, { x: 0, y: 0, duration: 0.8, ease: "expo.out" });
        magnet = mag;
        const r = mag.getBoundingClientRect();
        gs.to(mag, {
          x: (e.clientX - (r.left + r.width / 2)) * 0.28,
          y: (e.clientY - (r.top + r.height / 2)) * 0.34,
          duration: 0.9,
          ease: "expo.out",
        });
      } else if (magnet) {
        gs.to(magnet, { x: 0, y: 0, duration: 0.9, ease: "expo.out" });
        magnet = null;
      }
    };

    const setMode = (mode: string | null) => {
      const isView = mode === "view";
      gs.to(ring.current, {
        width: isView ? 78 : 34,
        height: isView ? 78 : 34,
        borderColor: isView ? "rgba(237,232,223,0)" : "rgba(237,232,223,0.6)",
        backgroundColor: isView ? "#5C1A1B" : "rgba(237,232,223,0)",
        duration: 0.5,
        ease: "expo.out",
      });
      gs.to(dot.current, {
        opacity: isView ? 0 : 1,
        scale: mode === "link" ? 2.4 : 1,
        duration: 0.4,
        ease: "power3.out",
      });
      if (label.current) {
        label.current.textContent = isView ? "VIEW" : "";
        gs.to(label.current, {
          opacity: isView ? 1 : 0,
          duration: 0.35,
          ease: "power3.out",
        });
      }
    };

    const onOver = (e: MouseEvent) => {
      const t = e.target as HTMLElement | null;
      const el = t?.closest?.("[data-cursor]") as HTMLElement | null;
      setMode(el ? el.dataset.cursor || null : null);
    };

    window.addEventListener("mousemove", onMove, { passive: true });
    window.addEventListener("mouseover", onOver, { passive: true });

    return () => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseover", onOver);
      document.body.classList.remove("has-cursor");
    };
  }, []);

  return (
    <div aria-hidden="true" className="pointer-events-none fixed inset-0 z-[130] hidden md:block">
      <div
        ref={ring}
        className="absolute left-0 top-0 flex h-[34px] w-[34px] items-center justify-center rounded-full border border-bone/60"
      >
        <span
          ref={label}
          className="label select-none text-[9px] text-bone opacity-0"
        />
      </div>
      <div
        ref={dot}
        className="absolute left-0 top-0 h-[5px] w-[5px] rounded-full bg-bone"
      />
    </div>
  );
}
