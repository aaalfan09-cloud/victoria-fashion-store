import { useEffect, useRef } from "react";
import { g, ST, reduced } from "../lib/anim";
import { runwayLooks, type RunwayLook } from "../data/products";

export default function Runway({
  paused,
  onSelectLook,
}: {
  paused: boolean;
  onSelectLook: (look: RunwayLook) => void;
}) {
  const root = useRef<HTMLElement>(null);
  const scroller = useRef<HTMLDivElement>(null);
  const strip = useRef<HTMLDivElement>(null);
  const counter = useRef<HTMLSpanElement>(null);
  const line = useRef<HTMLDivElement>(null);
  const tweenRef = useRef<any>(null);
  const pausedRef = useRef(paused);

  useEffect(() => {
    pausedRef.current = paused;
    const tween = tweenRef.current;
    if (!tween) return;
    if (paused) {
      tween.pause();
    } else {
      tween.resume();
      tween.scrollTrigger?.update();
    }
  }, [paused]);

  useEffect(() => {
    const scrollerEl = scroller.current;
    if (!scrollerEl) return;

    const syncMobileProgress = () => {
      if (window.innerWidth >= 768) return;
      const maxScroll = Math.max(scrollerEl.scrollWidth - scrollerEl.clientWidth, 1);
      const ratio = Math.min(Math.max(scrollerEl.scrollLeft / maxScroll, 0), 1);
      const minStep = 1 / runwayLooks.length;
      const visual = minStep + ratio * (1 - minStep);
      if (line.current) {
        line.current.style.transform = `scaleX(${visual})`;
      }
      if (counter.current) {
        const idx = Math.min(
          runwayLooks.length - 1,
          Math.max(0, Math.round(ratio * (runwayLooks.length - 1)))
        );
        counter.current.textContent = String(idx + 1).padStart(2, "0");
      }
    };

    syncMobileProgress();
    scrollerEl.addEventListener("scroll", syncMobileProgress, { passive: true });
    window.addEventListener("resize", syncMobileProgress);
    return () => {
      scrollerEl.removeEventListener("scroll", syncMobileProgress);
      window.removeEventListener("resize", syncMobileProgress);
    };
  }, []);

  useEffect(() => {
    const gs = g();
    const st = ST();
    const section = root.current;
    const track = strip.current;
    if (!gs || !st || !section || !track) return;
    if (reduced()) return;

    const mm = gs.matchMedia();

    mm.add("(min-width: 768px)", () => {
      const items = gs.utils.toArray("[data-look]") as HTMLElement[];
      const distance = () => Math.max(track.scrollWidth - window.innerWidth, 1);

      const shape = () => {
        const mid = window.innerWidth / 2;
        let closest = 0;
        let best = Infinity;
        items.forEach((el, i) => {
          const r = el.getBoundingClientRect();
          const d = Math.abs(r.left + r.width / 2 - mid);
          if (d < best) {
            best = d;
            closest = i;
          }
          const n = Math.min(d / (window.innerWidth * 0.62), 1);
          gs.set(el, {
            scale: 1 - n * 0.22,
            rotateY: ((r.left + r.width / 2 - mid) / mid) * -16,
            opacity: 1 - n * 0.55,
            filter: `grayscale(${Math.round(n * 85)}%) brightness(${1 - n * 0.3})`,
          });
        });
        if (counter.current)
          counter.current.textContent = String(closest + 1).padStart(2, "0");
      };

      tweenRef.current = gs.to(track, {
        x: () => -distance(),
        ease: "none",
        scrollTrigger: {
          trigger: section,
          start: "top top",
          end: () => "+=" + distance() * 1.1,
          pin: true,
          scrub: 1,
          anticipatePin: 1,
          invalidateOnRefresh: true,
          onUpdate: (self: any) => {
            if (pausedRef.current) return;
            if (line.current)
              line.current.style.transform = `scaleX(${self.progress})`;
            shape();
          },
          onRefresh: () => {
            if (!pausedRef.current) shape();
          },
        },
      });

      shape();

      return () => {
        tweenRef.current = null;
        gs.set(track, { clearProps: "transform" });
        gs.set(items, { clearProps: "transform,opacity,filter" });
      };
    });

    return () => {
      tweenRef.current = null;
      mm.revert();
    };
  }, []);

  return (
    <section
      ref={root}
      data-jiro-section="runway"
      data-jiro-label="Runway"
      id="runway"
      className="relative overflow-hidden bg-ink"
    >
      <div className="flex min-h-0 flex-col justify-center py-12 md:min-h-[100svh] md:py-0">
        <div className="flex items-end justify-between px-5 pb-6 md:px-10 md:pb-12">
          <div>
            <p className="label text-bone/45">02 — Runway</p>
            <h2 className="mt-3 font-display text-[9vw] leading-[0.9] tracking-[-0.03em] text-bone md:text-[4.2vw]">
              The walk
            </h2>
          </div>
          <p className="label text-right text-bone/60">
            Look <span ref={counter}>01</span> / {String(runwayLooks.length).padStart(2, "0")}
            <br />
            <span className="text-bone/35">Palazzo Corsini</span>
          </p>
        </div>

        <div
          ref={scroller}
          className="w-full overflow-x-auto no-scrollbar md:overflow-visible"
          style={{ perspective: "1400px" }}
        >
          <div
            ref={strip}
            className="flex w-max items-center gap-4 pl-5 pr-12 will-change-transform md:gap-8 md:px-[14vw]"
          >
            {runwayLooks.map((look, i) => (
              <figure
                key={look.no}
                data-look
                className="relative w-[68vw] shrink-0 sm:w-[44vw] md:w-[26vw]"
                style={{ transformStyle: "preserve-3d" }}
              >
                <button
                  type="button"
                  onClick={() => onSelectLook(look)}
                  data-cursor="view"
                  aria-label={`View Look ${look.no} — ${look.title}`}
                  className="group block w-full text-left"
                >
                  <div className="relative aspect-[3/4.4] w-full overflow-hidden bg-bone">
                    <img
                      key={look.src}
                      src={look.src}
                      alt={`SS26 runway look ${look.no} — ${look.title}`}
                      width={900}
                      height={1320}
                      loading={i < 2 ? "eager" : "lazy"}
                      className="h-full w-full object-cover transition-transform duration-[1100ms] ease-out group-hover:scale-[1.03]"
                    />
                  </div>
                </button>
                <figcaption className="mt-3 flex items-baseline justify-between">
                  <span className="label text-bone/70">{look.title}</span>
                  <span className="label text-bone/35">Look {look.no}</span>
                </figcaption>
              </figure>
            ))}
          </div>
        </div>

        <div className="mt-6 px-5 md:mt-12 md:px-10">
          <div className="h-[2px] w-full overflow-hidden bg-bone/15 md:h-px">
            <div
              ref={line}
              className="h-full w-full origin-left"
              style={{ background: "#5C1A1B", transform: "scaleX(0.1)" }}
            />
          </div>
          <p className="label mt-3 text-bone/35 md:mt-4">
            Scroll to walk the show — seventeen looks, ten shown
          </p>
        </div>
      </div>
    </section>
  );
}
