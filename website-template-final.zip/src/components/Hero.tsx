import { useEffect, useLayoutEffect, useRef } from "react";
import { g, ST, reduced, scrollToId } from "../lib/anim";

const LETTERS = "VICTORIA".split("");

/* REPLACE WITH REAL PHOTOS */
const HERO_IMG =
  "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=1800&q=80&auto=format&fit=crop";

export default function Hero({ ready }: { ready: boolean }) {
  const root = useRef<HTMLElement>(null);
  const img = useRef<HTMLImageElement>(null);
  const played = useRef(false);

  useLayoutEffect(() => {
    const gs = g();
    const el = root.current;
    if (!el || !gs || reduced()) return;
    gs.set(el.querySelectorAll("[data-letter]"), { y: 36, opacity: 0 });
    gs.set(el.querySelectorAll("[data-rise]"), { yPercent: 100, opacity: 0 });
  }, []);

  /* entrance */
  useEffect(() => {
    if (!ready || played.current) return;
    played.current = true;

    const gs = g();
    const el = root.current;
    if (!el) return;
    if (!gs || reduced()) {
      el.querySelectorAll<HTMLElement>("[data-letter]").forEach((n) => {
        n.style.transform = "none";
        n.style.opacity = "1";
      });
      el.querySelectorAll<HTMLElement>("[data-rise]").forEach((n) => {
        n.style.transform = "none";
        n.style.opacity = "1";
      });
      return;
    }

    const tl = gs.timeline({ delay: 0.1 });
    tl.to(el.querySelectorAll("[data-letter]"), {
      y: 0,
      opacity: 1,
      duration: 1.3,
      ease: "expo.out",
      stagger: 0.06,
    })
      .to(
        el.querySelectorAll("[data-rise]"),
        { yPercent: 0, opacity: 1, duration: 1.1, ease: "expo.out", stagger: 0.08 },
        "-=0.9"
      )
      .fromTo(
        img.current,
        { scale: 1.22 },
        { scale: 1, duration: 1.6, ease: "expo.out" },
        0
      )
      .fromTo(
        el.querySelector("[data-badge]"),
        { opacity: 0, scale: 0.8 },
        { opacity: 1, scale: 1, duration: 1, ease: "expo.out" },
        "-=1"
      );
  }, [ready]);

  /* parallax + scale down on scroll */
  useEffect(() => {
    const gs = g();
    const st = ST();
    if (!gs || !st || reduced() || !root.current) return;

    const ctx = gs.context(() => {
      gs.to(img.current, {
        yPercent: 16,
        scale: 0.88,
        ease: "none",
        scrollTrigger: {
          trigger: root.current,
          start: "top top",
          end: "bottom top",
          scrub: true,
        },
      });
      gs.to("[data-hero-type]", {
        yPercent: -28,
        opacity: 0.25,
        ease: "none",
        scrollTrigger: {
          trigger: root.current,
          start: "top top",
          end: "bottom top",
          scrub: true,
        },
      });
    }, root);
    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={root}
      data-jiro-section="hero"
      data-jiro-label="Hero"
      className="relative min-h-[100svh] w-full overflow-x-clip bg-ink"
    >
      <div className="absolute inset-0 overflow-hidden bg-bone">
        <img
          key={HERO_IMG}
          ref={img}
          src={HERO_IMG}
          alt="VICTORIA SS26 opening look photographed on a Florence rooftop"
          width={1800}
          height={2400}
          loading="eager"
          className="h-full w-full object-cover object-[50%_30%] opacity-80"
        />
        <div className="absolute inset-0 bg-ink/45" />
      </div>

      <div className="relative z-10 flex min-h-[100svh] flex-col justify-between px-4 pb-[max(2rem,env(safe-area-inset-bottom))] pt-24 md:px-10 md:pb-10 md:pt-32">
        <div className="flex items-start justify-between gap-6">
          <div className="overflow-hidden">
            <p
              data-rise
              className="label max-w-[20ch] text-bone/70 opacity-0"
            >
              Spring / Summer 2026 — Collection 14
            </p>
          </div>
          <div className="overflow-hidden">
            <p
              data-rise
              className="label text-right text-bone/70 opacity-0"
            >
              Shown 14 Feb
              <br />
              Palazzo Corsini
            </p>
          </div>
        </div>

        <div data-hero-type className="relative w-full">
          <h1
            className="flex w-full justify-center whitespace-nowrap font-display text-[clamp(2.85rem,16.5vw,12rem)] leading-none tracking-[-0.02em] text-bone"
            style={{ fontKerning: "normal", fontFeatureSettings: '"kern" 1' }}
          >
            {LETTERS.map((l, i) => (
              <span key={i} data-letter className="inline-block">
                {l}
              </span>
            ))}
          </h1>

          <div className="mt-6 flex flex-col gap-6 border-t border-bone/20 pt-5 md:flex-row md:items-end md:justify-between">
            <div className="overflow-hidden">
              <p
                data-rise
                className="max-w-[34ch] font-display text-2xl leading-[1.15] text-bone opacity-0 md:text-[2.1rem]"
              >
                Dressed for the quiet entrance.
              </p>
            </div>
            <div className="overflow-hidden">
              <div data-rise className="opacity-0">
                <a
                  href="#collection"
                  onClick={(e) => {
                    e.preventDefault();
                    scrollToId("collection");
                  }}
                  data-cursor="link"
                  data-magnetic
                  className="btn btn-solid"
                >
                  Enter the collection
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* rotating badge */}
      <div
        data-badge
        className="absolute bottom-[38%] right-4 z-10 h-[108px] w-[108px] opacity-0 md:bottom-auto md:right-10 md:top-[28%] md:h-[148px] md:w-[148px]"
      >
        <svg viewBox="0 0 160 160" className="spin-slow h-full w-full">
          <defs>
            <path
              id="badge-circle"
              d="M80,80 m-62,0 a62,62 0 1,1 124,0 a62,62 0 1,1 -124,0"
              fill="none"
            />
          </defs>
          <text
            fill="#EDE8DF"
            fontSize="12.5"
            letterSpacing="4.6"
            fontFamily="Inter Tight, sans-serif"
          >
            <textPath href="#badge-circle" startOffset="0">
              NEW COLLECTION — SS26 — NEW COLLECTION — SS26 —
            </textPath>
          </text>
        </svg>
        <span className="label absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-bone/80">
          14
        </span>
      </div>
    </section>
  );
}
