import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { g, ST, money, reduced } from "../lib/anim";
import { categories, products, type Product } from "../data/products";

const REVEAL_EASE = "cubic-bezier(0.22, 1, 0.36, 1)";

export default function Collection({
  onQuickView,
  onAdd,
}: {
  onQuickView: (p: Product) => void;
  onAdd: (id: string) => void;
}) {
  const grid = useRef<HTMLDivElement>(null);
  const [filter, setFilter] = useState<string>("All");
  const [displayedFilter, setDisplayedFilter] = useState<string>("All");
  const [enterTick, setEnterTick] = useState(0);
  const [observeTick, setObserveTick] = useState(0);
  const [revealedIds, setRevealedIds] = useState<Record<string, boolean>>({});
  const [isReduced, setIsReduced] = useState<boolean>(() => reduced());

  const filterTl = useRef<any>(null);
  const lockedHeight = useRef<number | null>(null);
  const pendingEnter = useRef(false);

  /* watch prefers-reduced-motion */
  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const sync = () => setIsReduced(mq.matches);
    sync();
    mq.addEventListener("change", sync);
    return () => mq.removeEventListener("change", sync);
  }, []);

  /* IntersectionObserver per card: trigger once at 20% visible */
  useEffect(() => {
    const el = grid.current;
    if (!el || isReduced) return;

    const cards = Array.from(
      el.querySelectorAll<HTMLElement>("[data-card-id]")
    );
    if (cards.length === 0) return;

    const observer = new IntersectionObserver(
      (entries) => {
        const newlyVisible: string[] = [];
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const id = (entry.target as HTMLElement).dataset.cardId;
            if (id) newlyVisible.push(id);
            observer.unobserve(entry.target);
          }
        });
        if (newlyVisible.length > 0) {
          setRevealedIds((prev) => {
            const next = { ...prev };
            let changed = false;
            for (const id of newlyVisible) {
              if (!next[id]) {
                next[id] = true;
                changed = true;
              }
            }
            return changed ? next : prev;
          });
        }
      },
      {
        threshold: 0.2,
      }
    );

    const raf = requestAnimationFrame(() => {
      cards.forEach((card) => observer.observe(card));
    });

    return () => {
      cancelAnimationFrame(raf);
      observer.disconnect();
    };
  }, [observeTick, isReduced]);

  /* subtle inner-frame scroll parallax (~4% shift inside scale(1.1) overflow-hidden) */
  useEffect(() => {
    const el = grid.current;
    if (!el) return;

    const nodes = Array.from(
      el.querySelectorAll<HTMLElement>("[data-parallax]")
    );
    if (nodes.length === 0) return;

    if (isReduced) {
      nodes.forEach((n) => {
        n.style.transform = "none";
      });
      return;
    }

    let rafId = 0;

    const update = () => {
      rafId = 0;
      const vh = window.innerHeight || 1;
      for (const node of nodes) {
        const frame = node.parentElement;
        if (!frame) continue;
        const rect = frame.getBoundingClientRect();
        if (rect.bottom < -vh * 0.25 || rect.top > vh * 1.25) continue;
        const center = rect.top + rect.height * 0.5;
        const progress = Math.max(-1, Math.min(1, (vh * 0.5 - center) / (vh * 0.65)));
        const shift = progress * 4;
        node.style.transform = `translate3d(0, ${shift.toFixed(3)}%, 0) scale(1.1)`;
      }
    };

    const onScroll = () => {
      if (!rafId) rafId = requestAnimationFrame(update);
    };

    update();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll, { passive: true });

    return () => {
      if (rafId) cancelAnimationFrame(rafId);
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
    };
  }, [displayedFilter, enterTick, isReduced]);

  /* category change with height-locked fade out */
  const change = (c: string) => {
    if (c === filter) return;
    setFilter(c);

    const el = grid.current;
    const gs = g();
    if (!el || !gs || isReduced) {
      setRevealedIds({});
      setDisplayedFilter(c);
      setObserveTick((t) => t + 1);
      return;
    }

    if (filterTl.current) {
      filterTl.current.kill();
      filterTl.current = null;
    }

    const currentHeight = el.getBoundingClientRect().height;
    lockedHeight.current = currentHeight;
    el.style.height = `${currentHeight}px`;
    el.style.overflow = "hidden";

    const currentItems = el.querySelectorAll("[data-card], [data-empty]");
    pendingEnter.current = true;

    const tl = gs.timeline({
      onComplete: () => {
        filterTl.current = null;
        setRevealedIds({});
        setDisplayedFilter(c);
        setEnterTick((t) => t + 1);
      },
    });

    if (currentItems.length > 0) {
      tl.to(currentItems, {
        opacity: 0,
        duration: 0.25,
        ease: "power2.out",
      });
    }

    filterTl.current = tl;
  };

  /* animate container to new height + re-observe filtered cards */
  useLayoutEffect(() => {
    const el = grid.current;
    if (!el) return;

    if (!pendingEnter.current) {
      if (isReduced) {
        el.style.height = "";
        el.style.overflow = "";
        ST()?.refresh();
      }
      return;
    }
    pendingEnter.current = false;

    const gs = g();
    const prevHeight = lockedHeight.current ?? el.getBoundingClientRect().height;
    lockedHeight.current = null;

    if (!gs || isReduced) {
      el.style.height = "";
      el.style.overflow = "";
      ST()?.refresh();
      return;
    }

    el.style.height = "auto";
    const nextHeight = el.getBoundingClientRect().height;
    el.style.height = `${prevHeight}px`;

    const emptyMsg = el.querySelector("[data-empty]");
    if (emptyMsg) {
      gs.set(emptyMsg, { opacity: 0, y: 12 });
    }

    const tl = gs.timeline({
      onComplete: () => {
        filterTl.current = null;
        el.style.height = "";
        el.style.overflow = "";
        const lenis = (window as any).__lenis;
        if (lenis && lenis.resize) lenis.resize();
        ST()?.refresh();
        setObserveTick((t) => t + 1);
      },
    });

    tl.to(el, {
      height: nextHeight,
      duration: 0.35,
      ease: "power2.out",
    });

    if (emptyMsg) {
      tl.to(
        emptyMsg,
        {
          opacity: 1,
          y: 0,
          duration: 0.3,
          ease: "power2.out",
        },
        "-=0.15"
      );
    }

    filterTl.current = tl;
  }, [displayedFilter, enterTick, isReduced]);

  const visibleProducts = products.filter(
    (p) => displayedFilter === "All" || p.category === displayedFilter
  );

  return (
    <section
      data-jiro-section="collection"
      data-jiro-label="Collection"
      id="collection"
      className="relative bg-ink px-4 pb-28 pt-10 md:px-10 md:pb-44 md:pt-32"
    >
      <div className="flex flex-col gap-8 border-b border-bone/15 pb-6 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="label text-bone/45">03 — Collection</p>
          <h2 className="mt-3 font-display text-[12vw] leading-[0.86] tracking-[-0.035em] text-bone md:text-[6vw]">
            Eight pieces
          </h2>
        </div>

        <div className="no-scrollbar -mx-4 flex flex-nowrap items-center gap-3 overflow-x-auto px-4 md:mx-0 md:px-0">
          {categories.map((c) => (
            <button
              key={c}
              type="button"
              onClick={() => change(c)}
              aria-pressed={filter === c}
              data-cursor="link"
              className={`btn btn-sm min-h-[44px] shrink-0 ${
                filter === c ? "btn-solid" : "btn-ghost"
              }`}
            >
              {c}
            </button>
          ))}
        </div>
      </div>

      <div
        ref={grid}
        className="mt-12 grid grid-cols-2 items-start gap-x-4 gap-y-12 md:mt-24 md:grid-cols-2 md:gap-x-8 md:gap-y-16"
      >
        {visibleProducts.length === 0 ? (
          <p
            data-empty
            className="label col-span-2 py-12 text-bone/55"
          >
            No pieces
          </p>
        ) : (
          visibleProducts.map((p, index) => {
            const isRevealed = isReduced || Boolean(revealedIds[p.id]);
            const colDelay = index % 2 === 1 ? 0.12 : 0;

            return (
              <article
                key={`${displayedFilter}-${p.id}`}
                data-card
                data-card-id={p.id}
                className="col-span-1 mt-0 flex flex-col will-change-[transform,opacity]"
                style={{
                  opacity: isRevealed ? 1 : 0,
                  transform: isRevealed ? "translate3d(0, 0, 0)" : "translate3d(0, 32px, 0)",
                  transition: isReduced
                    ? "none"
                    : `opacity 0.9s ${REVEAL_EASE} ${colDelay}s, transform 0.9s ${REVEAL_EASE} ${colDelay}s`,
                }}
              >
                <div className="flex items-baseline justify-between gap-2 border-b border-bone/15 pb-2">
                  <span className="label tracking-[0.12em] text-bone/40 md:tracking-[0.2em]">
                    {p.no}
                  </span>
                  <span className="label truncate tracking-[0.12em] text-bone/40 md:tracking-[0.2em]">
                    {p.meta}
                  </span>
                </div>

                <button
                  type="button"
                  onClick={() => onQuickView(p)}
                  data-cursor="view"
                  aria-label={`Quick view — ${p.name}`}
                  className="group mt-3 block w-full text-left md:mt-4"
                >
                  <div
                    data-frame
                    className="relative aspect-[4/5] w-full overflow-hidden border border-white/[0.06] bg-transparent"
                  >
                    <div
                      data-parallax
                      className="h-full w-full will-change-transform"
                    >
                      <div
                        className="relative h-full w-full will-change-[transform,filter]"
                        style={{
                          filter: isRevealed ? "blur(0px)" : "blur(8px)",
                          transform: isRevealed ? "scale(1)" : "scale(1.08)",
                          transition: isReduced
                            ? "none"
                            : `filter 1.1s ${REVEAL_EASE} ${colDelay}s, transform 1.1s ${REVEAL_EASE} ${colDelay}s`,
                        }}
                      >
                        <img
                          key={p.image}
                          src={p.image}
                          alt={`${p.name} in ${p.material}`}
                          width={1200}
                          height={1500}
                          loading="lazy"
                          className="h-full w-full object-cover transition-transform duration-[1200ms] ease-out group-hover:scale-[1.04]"
                        />
                        <img
                          key={p.hover}
                          src={p.hover}
                          alt=""
                          aria-hidden="true"
                          width={1200}
                          height={1500}
                          loading="lazy"
                          className="absolute inset-0 h-full w-full object-cover transition-all duration-[900ms] ease-out [clip-path:inset(0%_0%_0%_100%)] group-hover:scale-[1.04] group-hover:[clip-path:inset(0%_0%_0%_0%)]"
                        />
                      </div>
                    </div>
                  </div>
                </button>

                <div
                  style={{
                    opacity: isRevealed ? 1 : 0,
                    transition: isReduced
                      ? "none"
                      : `opacity 0.6s ease-out ${colDelay + 0.25}s`,
                  }}
                >
                  <div className="mt-3 flex flex-col items-start gap-1 text-left md:mt-5 md:flex-row md:items-baseline md:justify-between md:gap-6">
                    <div className="min-w-0 overflow-hidden">
                      <h3 className="font-display text-[15px] leading-snug text-bone md:text-[1.75rem] md:leading-tight">
                        {p.name}
                      </h3>
                      <p className="mt-1 text-[11px] uppercase leading-snug tracking-[0.12em] text-bone/50 md:label md:mt-1.5 md:text-bone/45">
                        {p.material}
                      </p>
                    </div>
                    <span className="mt-0.5 text-[14px] font-normal tracking-[0.06em] text-bone/90 md:label md:mt-0 md:shrink-0 md:whitespace-nowrap md:text-bone/80">
                      {money(p.price)}
                    </span>
                  </div>

                  <div className="mt-4 flex flex-col gap-2.5 md:mt-5 md:flex-row md:flex-nowrap md:items-stretch md:gap-3">
                    <button
                      type="button"
                      onClick={() => onAdd(p.id)}
                      data-cursor="link"
                      data-magnetic
                      className="btn btn-solid w-full md:w-auto"
                    >
                      Add to bag +
                    </button>
                    <button
                      type="button"
                      onClick={() => onQuickView(p)}
                      data-cursor="link"
                      className="btn btn-ghost w-full md:w-auto"
                    >
                      Details
                    </button>
                  </div>
                </div>
              </article>
            );
          })
        )}
      </div>
    </section>
  );
}
