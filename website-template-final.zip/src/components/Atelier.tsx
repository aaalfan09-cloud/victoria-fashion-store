import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { g, ST, reduced } from "../lib/anim";
import { atelierAlts, atelierImages } from "../data/products";

const CHAPTERS = [
  {
    no: "01",
    title: "The cloth",
    body: "Three mills, all within a day of Florence. We buy the whole piece or none of it, which is why a colour never returns once the bolt is finished.",
  },
  {
    no: "02",
    title: "The hand",
    body: "Every garment is assigned to one tailor from first cut to final press. Their initials are inked on the inside of the facing, under the lining.",
  },
  {
    no: "03",
    title: "The city",
    body: "Via Maggio, second courtyard, third door. Twelve people, no production line, and a window that faces the Arno when the shutters are open.",
  },
  {
    no: "04",
    title: "The fitting",
    body: "Every piece is tried on three times before we call it finished.",
  },
  {
    no: "05",
    title: "The label",
    body: "Our name sits inside the seam, where only you will find it.",
  },
  {
    no: "06",
    title: "The thread",
    body: "Each thread is chosen one by one so the colour disappears into the cloth.",
  },
];

const PLATE_LAYOUTS = [
  "aspect-[3/4] w-[58%] mr-auto md:w-[82%] md:max-w-[420px] md:ml-[6%] md:mr-auto md:mt-0",
  "aspect-[4/5] w-[56%] ml-auto md:w-[80%] md:max-w-[420px] md:ml-auto md:mr-[4%] md:-mt-[4vh]",
  "aspect-[3/4] w-[60%] mr-auto md:w-[84%] md:max-w-[420px] md:ml-[10%] md:mr-auto md:mt-[4vh]",
  "aspect-[4/5] w-[56%] ml-auto md:w-[78%] md:max-w-[420px] md:ml-auto md:mr-[6%] md:-mt-[5vh]",
  "aspect-[3/4] w-[58%] mr-auto md:w-[82%] md:max-w-[420px] md:ml-[4%] md:mr-auto md:mt-[3vh]",
  "aspect-[4/5] w-[60%] ml-auto md:w-[80%] md:max-w-[420px] md:ml-auto md:mr-[5%] md:-mt-[4vh]",
];

const STATS = [
  { value: 42, suffix: "", label: "hours per garment" },
  { value: 100, suffix: "%", label: "Italian wool" },
  { value: null, suffix: "", label: "Made in Florence", text: "Firenze" },
];

export default function Atelier() {
  const root = useRef<HTMLElement>(null);
  const chapterRefs = useRef<(HTMLDivElement | null)[]>([]);
  const plateRefs = useRef<(HTMLElement | null)[]>([]);
  const currentShown = useRef<number>(0);
  const chapterTl = useRef<any>(null);
  const [active, setActive] = useState(0);

  /* Initialize chapter stack so only Chapter 01 is visible initially */
  useLayoutEffect(() => {
    const gs = g();
    chapterRefs.current.forEach((node, i) => {
      if (!node) return;
      const isFirst = i === 0;
      if (gs) {
        gs.set(node, {
          opacity: isFirst ? 1 : 0,
          y: 0,
          visibility: isFirst ? "visible" : "hidden",
          pointerEvents: isFirst ? "auto" : "none",
        });
      } else {
        node.style.opacity = isFirst ? "1" : "0";
        node.style.visibility = isFirst ? "visible" : "hidden";
        node.style.pointerEvents = isFirst ? "auto" : "none";
      }
    });
  }, []);

  /* Sync active chapter with whichever plate crosses the viewport centerline */
  useEffect(() => {
    const plates = plateRefs.current.filter(Boolean) as HTMLElement[];
    if (plates.length === 0) return;

    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (!entry.isIntersecting) continue;
          const idx = Number((entry.target as HTMLElement).dataset.plateIndex);
          if (!Number.isNaN(idx)) {
            setActive((prev) => (prev === idx ? prev : idx));
          }
        }
      },
      {
        threshold: 0,
        rootMargin: "-45% 0px -45% 0px",
      }
    );

    plates.forEach((plate) => observer.observe(plate));
    return () => observer.disconnect();
  }, []);

  /* Non-overlapping sequential chapter transition */
  useEffect(() => {
    const prevIdx = currentShown.current;
    if (prevIdx === active) return;

    const gs = g();
    const prevNode = chapterRefs.current[prevIdx];
    const nextNode = chapterRefs.current[active];

    if (chapterTl.current) {
      chapterTl.current.kill();
      chapterTl.current = null;
    }

    // Ensure every other chapter is completely hidden so text never stacks
    chapterRefs.current.forEach((node, i) => {
      if (!node || i === prevIdx || i === active) return;
      if (gs) {
        gs.set(node, {
          opacity: 0,
          y: 0,
          visibility: "hidden",
          pointerEvents: "none",
        });
      } else {
        node.style.opacity = "0";
        node.style.visibility = "hidden";
        node.style.pointerEvents = "none";
      }
    });

    if (!gs || reduced()) {
      if (prevNode) {
        prevNode.style.opacity = "0";
        prevNode.style.visibility = "hidden";
        prevNode.style.pointerEvents = "none";
      }
      if (nextNode) {
        nextNode.style.opacity = "1";
        nextNode.style.transform = "none";
        nextNode.style.visibility = "visible";
        nextNode.style.pointerEvents = "auto";
      }
      currentShown.current = active;
      return;
    }

    const tl = gs.timeline({
      onComplete: () => {
        chapterTl.current = null;
      },
    });

    if (prevNode) {
      tl.to(prevNode, {
        opacity: 0,
        y: -12,
        duration: 0.25,
        ease: "power2.out",
      }).set(prevNode, {
        visibility: "hidden",
        pointerEvents: "none",
        y: 0,
      });
    }

    if (nextNode) {
      tl.set(nextNode, {
        opacity: 0,
        y: 12,
        visibility: "visible",
        pointerEvents: "auto",
      }).to(nextNode, {
        opacity: 1,
        y: 0,
        duration: 0.35,
        ease: "power2.out",
      });
    }

    currentShown.current = active;
    chapterTl.current = tl;
  }, [active]);

  /* Reveal, stats counters, and desktop/tablet parallax */
  useEffect(() => {
    const gs = g();
    const st = ST();
    const el = root.current;
    if (!gs || !st || !el || reduced()) return;

    const mm = gs.matchMedia();

    const ctx = gs.context(() => {
      const plates = gs.utils.toArray("[data-atelier-img]") as HTMLElement[];

      plates.forEach((plate) => {
        gs.fromTo(
          plate,
          { opacity: 0 },
          {
            opacity: 1,
            duration: 0.7,
            ease: "power2.out",
            scrollTrigger: {
              trigger: plate,
              start: "top 88%",
              once: true,
            },
          }
        );
      });

      mm.add("(min-width: 768px)", () => {
        const photos = gs.utils.toArray("[data-atelier-photo]") as HTMLElement[];
        photos.forEach((photo) => {
          gs.fromTo(
            photo,
            { yPercent: -5, scale: 1.1 },
            {
              yPercent: 5,
              scale: 1.1,
              ease: "none",
              scrollTrigger: {
                trigger: photo.parentElement,
                start: "top bottom",
                end: "bottom top",
                scrub: true,
              },
            }
          );
        });
      });

      (gs.utils.toArray("[data-count]") as HTMLElement[]).forEach((node) => {
        const target = Number(node.dataset.count || "0");
        const suffix = node.dataset.suffix || "";
        const obj = { v: 0 };
        gs.to(obj, {
          v: target,
          duration: 1.4,
          ease: "power3.out",
          scrollTrigger: { trigger: node, start: "top 88%", once: true },
          onUpdate: () => {
            node.textContent = Math.round(obj.v) + suffix;
          },
        });
      });
    }, el);

    return () => {
      mm.revert();
      ctx.revert();
    };
  }, []);

  return (
    <section
      ref={root}
      data-jiro-section="atelier"
      data-jiro-label="Atelier"
      id="atelier"
      className="relative border-t border-bone/15 bg-ink"
    >
      <div className="grid grid-cols-1 md:grid-cols-2">
        {/* sticky left */}
        <div className="relative z-20 md:sticky md:top-0 md:h-[100svh]">
          <div className="flex h-full flex-col justify-between px-5 pb-10 pt-20 md:px-10 md:pb-14 md:pt-28">
            <p className="label text-bone/45">06 — Atelier</p>

            <div className="relative mt-10 h-[230px] sm:h-[220px] md:mt-0 md:h-[300px]">
              {CHAPTERS.map((c, i) => (
                <div
                  key={c.no}
                  ref={(el) => {
                    chapterRefs.current[i] = el;
                  }}
                  aria-hidden={i !== active}
                  className="absolute inset-x-0 top-0"
                >
                  <span className="label text-bone/40">Chapter {c.no}</span>
                  <h3 className="mt-5 font-display text-[12vw] leading-[0.9] tracking-[-0.03em] text-bone md:text-[4.4vw]">
                    {c.title}
                  </h3>
                  <p className="mt-6 max-w-[38ch] text-[0.98rem] leading-relaxed text-bone/65">
                    {c.body}
                  </p>
                </div>
              ))}
            </div>

            <div className="relative z-30 mt-12 grid grid-cols-1 gap-6 border-t border-bone/15 bg-ink pt-8 sm:grid-cols-3">
              {STATS.map((s) => (
                <div key={s.label}>
                  <p className="font-display text-[2.6rem] leading-none text-bone">
                    {s.value === null ? (
                      s.text
                    ) : (
                      <span data-count={s.value} data-suffix={s.suffix}>
                        0{s.suffix}
                      </span>
                    )}
                  </p>
                  <p className="label mt-3 text-bone/45">{s.label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* scrolling right */}
        <div className="relative z-10 flex flex-col gap-[14vh] px-5 pb-12 pt-0 md:gap-[16vh] md:px-10 md:pb-16 md:pt-12">
          {atelierImages.map((src, i) => (
            <figure
              key={src}
              ref={(el) => {
                plateRefs.current[i] = el;
              }}
              data-plate-index={i}
              data-atelier-img
              className={`relative overflow-hidden bg-bone ${
                PLATE_LAYOUTS[i] ?? "aspect-[3/4] w-[58%]"
              }`}
            >
              <img
                key={src}
                data-atelier-photo
                src={src}
                alt={
                  atelierAlts[i] ??
                  `Atelier work in Florence — ${CHAPTERS[i]?.title ?? "detail"}`
                }
                width={1200}
                height={1500}
                loading="lazy"
                className="h-full w-full object-cover will-change-transform"
              />
              <figcaption className="label absolute bottom-4 left-4 bg-ink/80 px-3 py-2 text-bone/80">
                Plate {String(i + 1).padStart(2, "0")}
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}
