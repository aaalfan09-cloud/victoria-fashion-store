import { useCallback, useEffect, useRef, useState } from "react";
import { ArrowUp } from "lucide-react";
import { g, reduced } from "../lib/anim";

export default function Preloader({ onDone }: { onDone: () => void }) {
  const root = useRef<HTMLDivElement>(null);
  const backdrop = useRef<HTMLDivElement>(null);
  const num = useRef<HTMLSpanElement>(null);
  const bar = useRef<HTMLDivElement>(null);
  const meta = useRef<HTMLDivElement>(null);
  const done = useRef(false);
  const dismissing = useRef(false);
  const touchStartY = useRef<number | null>(null);
  const [removed, setRemoved] = useState(false);

  const finish = useCallback(() => {
    if (done.current) return;
    done.current = true;
    onDone();
  }, [onDone]);

  const dismiss = useCallback(() => {
    if (dismissing.current || done.current) return;
    dismissing.current = true;

    const gs = g();
    const el = root.current;
    const bg = backdrop.current;
    if (!gs || !el || reduced()) {
      setRemoved(true);
      finish();
      return;
    }

    const tl = gs.timeline({
      onComplete: () => {
        setRemoved(true);
        finish();
      },
    });

    tl.to(
      el,
      {
        yPercent: -100,
        duration: 0.9,
        ease: "expo.out",
      },
      0
    );

    if (bg) {
      tl.to(
        bg,
        {
          opacity: 0,
          duration: 0.9,
          ease: "power2.out",
        },
        0
      );
    }
  }, [finish]);

  useEffect(() => {
    const gs = g();
    if (!gs || reduced()) {
      if (num.current) num.current.textContent = "100";
      if (bar.current) bar.current.style.transform = "scaleX(1)";
      return;
    }

    const counter = { v: 0 };
    const tl = gs.timeline();
    tl.to(counter, {
      v: 100,
      duration: 2.1,
      ease: "power3.out",
      onUpdate: () => {
        if (num.current)
          num.current.textContent = String(Math.round(counter.v)).padStart(
            3,
            "0"
          );
      },
    }).to(bar.current, { scaleX: 1, duration: 2.1, ease: "power3.out" }, 0);

    return () => {
      tl.kill();
    };
  }, []);

  useEffect(() => {
    if (removed) return;

    const onWheel = (e: WheelEvent) => {
      if (e.deltaY > 8) {
        dismiss();
      }
    };

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Enter" || e.key === "ArrowUp") {
        e.preventDefault();
        dismiss();
      }
    };

    const onTouchStart = (e: TouchEvent) => {
      touchStartY.current = e.touches[0]?.clientY ?? null;
    };

    const onTouchMove = (e: TouchEvent) => {
      if (touchStartY.current === null) return;
      const currentY = e.touches[0]?.clientY ?? touchStartY.current;
      if (touchStartY.current - currentY > 36) {
        touchStartY.current = null;
        dismiss();
      }
    };

    const onTouchEnd = (e: TouchEvent) => {
      if (touchStartY.current === null) return;
      const endY = e.changedTouches[0]?.clientY ?? touchStartY.current;
      if (touchStartY.current - endY > 36) {
        dismiss();
      }
      touchStartY.current = null;
    };

    window.addEventListener("wheel", onWheel, { passive: true });
    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("touchstart", onTouchStart, { passive: true });
    window.addEventListener("touchmove", onTouchMove, { passive: true });
    window.addEventListener("touchend", onTouchEnd, { passive: true });

    return () => {
      window.removeEventListener("wheel", onWheel);
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("touchstart", onTouchStart);
      window.removeEventListener("touchmove", onTouchMove);
      window.removeEventListener("touchend", onTouchEnd);
    };
  }, [removed, dismiss]);

  if (removed) return null;

  return (
    <>
      <div
        ref={backdrop}
        aria-hidden="true"
        className="pointer-events-none fixed inset-x-0 top-0 z-[119] h-[100dvh] w-full"
        style={{
          background:
            "linear-gradient(to bottom, rgba(10,10,10,0.55) 0%, rgba(10,10,10,0.45) 50%, rgba(10,10,10,0.7) 100%)",
          backdropFilter: "blur(2px)",
          WebkitBackdropFilter: "blur(2px)",
        }}
      />

      <div
        ref={root}
        data-jiro-section="preloader"
        data-jiro-label="Preloader"
        className="fixed inset-x-0 top-0 z-[120] flex h-[100dvh] w-full touch-none flex-col justify-between px-5 py-6 md:px-10 md:py-9"
      >
        <div
          ref={meta}
          className="label flex items-start justify-between text-bone/90"
        >
          <span>VICTORIA — Maison</span>
          <span className="hidden sm:block">Spring / Summer 26</span>
          <span>Firenze</span>
        </div>

        <div className="flex items-end justify-between gap-6">
          <span
            ref={num}
            className="font-display text-[26vw] leading-[0.78] tracking-[-0.03em] text-bone md:text-[16vw]"
          >
            000
          </span>
          <span className="label mb-3 hidden text-bone/85 md:block">
            Dressing the collection
          </span>
        </div>

        <div className="pb-[calc(92px+env(safe-area-inset-bottom))] md:pb-[calc(96px+env(safe-area-inset-bottom))]">
          <div className="h-px w-full bg-bone/35">
            <div
              ref={bar}
              className="h-px origin-left scale-x-0 bg-oxblood"
              style={{ background: "#5C1A1B" }}
            />
          </div>
          <p className="label mt-4 text-bone/85">
            Est. MMXIV — Via Maggio, Florence
          </p>
        </div>

        <div className="absolute bottom-[calc(32px+env(safe-area-inset-bottom))] left-1/2 -translate-x-1/2">
          <button
            type="button"
            onClick={dismiss}
            aria-label="Enter website"
            data-cursor="link"
            className="group flex flex-col items-center gap-2.5 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-bone"
          >
            <span className="label text-bone/95 transition-opacity duration-300 group-hover:text-bone">
              Enter
            </span>
            <span className="preloader-bob flex h-[56px] w-[56px] items-center justify-center rounded-full border border-bone/85 text-bone transition-colors duration-300 group-hover:border-bone group-hover:bg-bone/10">
              <ArrowUp className="h-5 w-5" strokeWidth={1.25} aria-hidden="true" />
            </span>
          </button>
        </div>
      </div>
    </>
  );
}
