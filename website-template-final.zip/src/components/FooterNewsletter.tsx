import { useEffect, useRef, useState } from "react";
import { g, ST, reduced } from "../lib/anim";

export default function FooterNewsletter() {
  const root = useRef<HTMLElement>(null);
  const markWrap = useRef<HTMLDivElement>(null);
  const mark = useRef<HTMLSpanElement>(null);
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [focused, setFocused] = useState(false);

  useEffect(() => {
    const gs = g();
    const st = ST();
    const el = root.current;
    if (!gs || !st || !el) return;
    if (reduced()) {
      if (mark.current) gs.set(mark.current, { yPercent: 0 });
      return;
    }

    const ctx = gs.context(() => {
      gs.fromTo(
        mark.current,
        { yPercent: 100 },
        {
          yPercent: 0,
          duration: 1.4,
          ease: "expo.out",
          scrollTrigger: {
            trigger: markWrap.current ?? el,
            start: "top 95%",
            once: true,
          },
        }
      );
      gs.fromTo(
        el.querySelectorAll("[data-foot-rise]"),
        { y: 26, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 1,
          ease: "power3.out",
          stagger: 0.08,
          scrollTrigger: { trigger: el, start: "top 85%", once: true },
        }
      );
    }, el);
    return () => ctx.revert();
  }, []);

  return (
    <footer
      ref={root}
      data-jiro-section="footer"
      data-jiro-label="Newsletter & Footer"
      id="newsletter"
      className="relative z-10 min-h-0 h-auto overflow-x-hidden border-t border-bone/15 bg-ink px-5 pb-8 pt-20 md:px-10 md:pb-10 md:pt-32"
    >
      <div className="grid grid-cols-12 gap-y-12">
        <div className="col-span-12 md:col-span-4">
          <p data-foot-rise className="label text-bone/45">
            06 — Correspondence
          </p>
          <p
            data-foot-rise
            className="mt-6 max-w-[26ch] font-display text-[1.8rem] leading-[1.15] text-bone md:text-[2.3rem]"
          >
            Two letters a season. Nothing else, ever.
          </p>
        </div>

        <div className="col-span-12 md:col-span-7 md:col-start-6">
          <form
            data-foot-rise
            onSubmit={(e) => {
              e.preventDefault();
              if (email.trim()) setSent(true);
            }}
            className="relative"
          >
            <label htmlFor="newsletter-email" className="label text-bone/45">
              Your email
            </label>
            <div className="relative mt-5 flex items-center gap-4">
              <input
                id="newsletter-email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                onFocus={() => setFocused(true)}
                onBlur={() => setFocused(false)}
                placeholder="name@domain.com"
                className="w-full min-w-0 bg-transparent pb-4 font-display text-[1.6rem] text-bone outline-none placeholder:text-bone/25 md:text-[2.2rem]"
              />
              <button
                type="submit"
                data-cursor="link"
                data-magnetic
                className="btn btn-solid mb-4 shrink-0"
              >
                {sent ? "Received" : "Subscribe"}
              </button>
            </div>
            <span className="absolute bottom-0 left-0 block h-px w-full bg-bone/20" />
            <span
              className={`absolute bottom-0 left-0 block h-px w-full origin-left transition-transform duration-[900ms] ${
                focused || sent ? "scale-x-100" : "scale-x-0"
              }`}
              style={{
                background: "#5C1A1B",
                transitionTimingFunction: "cubic-bezier(0.16, 1, 0.3, 1)",
              }}
            />
            <p className="label mt-4 text-bone/35">
              {sent
                ? "Noted. The next letter leaves Florence in March."
                : "No offers, no discounts. Show dates and atelier openings."}
            </p>
          </form>
        </div>
      </div>

      <div className="mt-16 grid grid-cols-1 gap-12 border-t border-bone/15 pt-10 sm:grid-cols-2 lg:grid-cols-4">
        <div className="min-w-0 [overflow-wrap:anywhere]">
          <p className="label text-bone/35">Maison</p>
          <ul className="mt-4 space-y-2">
            <li>
              <a
                href="#collection"
                data-cursor="link"
                className="label text-bone/70 transition-colors duration-300 hover:text-bone"
              >
                Collection
              </a>
            </li>
            <li>
              <a
                href="#atelier"
                data-cursor="link"
                className="label text-bone/70 transition-colors duration-300 hover:text-bone"
              >
                Atelier
              </a>
            </li>
            <li>
              <a
                href="#runway"
                data-cursor="link"
                className="label text-bone/70 transition-colors duration-300 hover:text-bone"
              >
                Runway
              </a>
            </li>
          </ul>
        </div>

        <div className="min-w-0 [overflow-wrap:anywhere]">
          <p className="label text-bone/35">Client care</p>
          <ul className="mt-4 space-y-2">
            <li>
              <a
                href="mailto:clients@victoria.studio"
                data-cursor="link"
                className="label inline-block max-w-full text-bone/70 transition-colors duration-300 hover:text-bone"
              >
                clients@victoria.studio
              </a>
            </li>
            <li>
              <a
                href="tel:+390550000000"
                data-cursor="link"
                className="label text-bone/70 transition-colors duration-300 hover:text-bone"
              >
                +39 055 0000 00
              </a>
            </li>
            <li>
              <a
                href="#lookbook"
                data-cursor="link"
                className="label text-bone/70 transition-colors duration-300 hover:text-bone"
              >
                Lookbook
              </a>
            </li>
          </ul>
        </div>

        <div className="min-w-0 [overflow-wrap:anywhere]">
          <p className="label text-bone/35">Showroom</p>
          <p className="label mt-4 text-bone/70">
            Via Maggio 41r
            <br />
            50125 Firenze, Italia
            <br />
            By appointment, Tue — Sat
          </p>
        </div>

        <div className="min-w-0 [overflow-wrap:anywhere]">
          <p className="label text-bone/35">Follow</p>
          <p className="label mt-4 text-bone/70">
            Instagram — Journal
            <br />
            Press enquiries
            <br />
            Firenze, MMXXVI
          </p>
        </div>
      </div>

      <div ref={markWrap} className="mt-20 overflow-hidden md:mt-28">
        <span
          ref={mark}
          className="block w-full pb-[0.12em] text-center font-display text-[20vw] leading-none tracking-[-0.045em] text-bone"
        >
          VICTORIA
        </span>
      </div>

      <div className="mt-6 flex flex-col gap-3 border-t border-bone/15 pt-5 md:grid md:grid-cols-3 md:items-center">
        <p className="label text-bone/35 md:text-left">
          © MMXXVI VICTORIA — Firenze
        </p>
        <p className="label text-bone/35 md:text-center">
          Privacy — Terms — Cookies
        </p>
        <p className="label text-bone/35 md:text-right">
          Dressed for the quiet entrance.
        </p>
      </div>
    </footer>
  );
}
