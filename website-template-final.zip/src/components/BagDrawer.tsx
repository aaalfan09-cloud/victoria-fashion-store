import { useEffect, useRef } from "react";
import { money } from "../lib/anim";
import type { BagLine } from "../App";
import type { Product } from "../data/products";

export default function BagDrawer({
  open,
  bag,
  products,
  scrollToCheckoutKey,
  onClose,
  onQty,
  onRemove,
}: {
  open: boolean;
  bag: BagLine[];
  products: Product[];
  scrollToCheckoutKey?: number;
  onClose: () => void;
  onQty: (id: string, size: string, delta: number) => void;
  onRemove: (id: string, size: string) => void;
}) {
  const listRef = useRef<HTMLDivElement>(null);
  const footerRef = useRef<HTMLDivElement>(null);

  const lines = bag
    .map((l) => ({ line: l, product: products.find((p) => p.id === l.id) }))
    .filter((x) => x.product) as { line: BagLine; product: Product }[];

  const subtotal = lines.reduce(
    (sum, x) => sum + x.product.price * x.line.qty,
    0
  );

  useEffect(() => {
    if (!open || !scrollToCheckoutKey) return;
    const id = window.setTimeout(() => {
      if (listRef.current) {
        listRef.current.scrollTo({
          top: listRef.current.scrollHeight,
          behavior: "smooth",
        });
      }
      footerRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
    }, 80);
    return () => window.clearTimeout(id);
  }, [open, scrollToCheckoutKey]);

  return (
    <div data-jiro-section="bag-drawer" data-jiro-label="Bag Drawer" aria-hidden={!open}>
      <div
        onClick={onClose}
        className={`fixed inset-0 z-[117] bg-ink/70 transition-opacity duration-700 ${
          open ? "opacity-100" : "pointer-events-none opacity-0"
        }`}
      />

      <aside
        role="dialog"
        aria-modal="true"
        aria-label="Shopping bag"
        className={`fixed right-0 top-0 z-[118] flex h-[100svh] w-full flex-col bg-ink text-bone transition-transform duration-[900ms] sm:w-[460px] ${
          open ? "translate-x-0" : "translate-x-full"
        }`}
        style={{
          transitionTimingFunction: "cubic-bezier(0.16, 1, 0.3, 1)",
          borderLeft: "1px solid rgba(237,232,223,0.18)",
        }}
      >
        <div className="flex items-center justify-between border-b border-bone/15 px-5 py-5 md:px-7">
          <span className="label text-bone/45">
            Bag — {lines.reduce((n, x) => n + x.line.qty, 0)} items
          </span>
          <button
            type="button"
            onClick={onClose}
            data-cursor="link"
            className="btn btn-ghost btn-sm"
          >
            Close
          </button>
        </div>

        <div ref={listRef} className="flex-1 overflow-y-auto no-scrollbar px-5 md:px-7">
          {lines.length === 0 && (
            <div className="flex h-full flex-col justify-center">
              <p className="font-display text-[2rem] leading-[1.1]">
                Your bag is empty.
              </p>
              <p className="label mt-5 text-bone/45">
                Eight pieces wait in the collection below.
              </p>
            </div>
          )}

          {lines.map(({ line, product }) => (
            <article
              key={product.id + line.size}
              className="flex gap-4 border-b border-bone/15 py-6"
            >
              <div className="h-[128px] w-[96px] shrink-0 overflow-hidden bg-bone">
                <img
                  key={product.image}
                  src={product.image}
                  alt={product.name}
                  width={192}
                  height={256}
                  loading="lazy"
                  className="h-full w-full object-cover"
                />
              </div>

              <div className="flex flex-1 flex-col justify-between">
                <div>
                  <div className="flex items-start justify-between gap-3">
                    <h3 className="font-display text-xl leading-tight">
                      {product.name}
                    </h3>
                    <span className="label text-bone/75">
                      {money(product.price * line.qty)}
                    </span>
                  </div>
                  <p className="label mt-2 text-bone/40">
                    {product.material} — Size {line.size}
                  </p>
                </div>

                <div className="mt-4 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => onQty(line.id, line.size, -1)}
                      aria-label={`Remove one ${product.name}`}
                      data-cursor="link"
                      className="btn btn-ghost btn-sm"
                    >
                      —
                    </button>
                    <span className="label min-w-6 text-center text-bone">
                      {line.qty}
                    </span>
                    <button
                      type="button"
                      onClick={() => onQty(line.id, line.size, 1)}
                      aria-label={`Add one ${product.name}`}
                      data-cursor="link"
                      className="btn btn-ghost btn-sm"
                    >
                      +
                    </button>
                  </div>
                  <button
                    type="button"
                    onClick={() => onRemove(line.id, line.size)}
                    data-cursor="link"
                    className="label text-bone/40 underline underline-offset-4 transition-colors duration-300 hover:text-bone"
                  >
                    Remove
                  </button>
                </div>
              </div>
            </article>
          ))}
        </div>

        <div ref={footerRef} className="border-t border-bone/15 px-5 py-6 md:px-7">
          <div className="flex items-baseline justify-between">
            <span className="label text-bone/45">Subtotal</span>
            <span className="font-display text-[1.9rem] leading-none">
              {money(subtotal)}
            </span>
          </div>
          <p className="label mt-3 text-bone/35">
            Duties and Florence-packed shipping calculated at checkout.
          </p>
          <button
            type="button"
            disabled={lines.length === 0}
            data-cursor="link"
            data-magnetic
            className="btn btn-solid mt-6 w-full"
          >
            Proceed to checkout
          </button>
        </div>
      </aside>
    </div>
  );
}
