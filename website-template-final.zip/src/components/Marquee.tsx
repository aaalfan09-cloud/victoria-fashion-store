import { useEffect, useRef } from "react";
import { g, ST, reduced } from "../lib/anim";

const WORDS = [
  "SS26",
  "Made in Florence",
  "Hand-finished",
  "Seventeen looks",
  "Appointment only",
  "Via Maggio 41r",
];

function Strip() {
  return (
    <span className="flex shrink-0 items-center">
      {WORDS.map((w, i) => (
        <span key={i} className="flex items-center">
          <span className="whitespace-nowrap px-6 font-display text-[11vw] leading-none tracking-[-0.02em] md:px-10 md:text-[5.4vw]">
            {w}
          </span>
          <span
            aria-hidden="true"
            className="h-2 w-2 shrink-0 rounded-full"
            style={{ background: "#5C1A1B" }}
          />
        </span>
      ))}
    </span>
  );
}

export default function Marquee() {
  const track = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const gs = g();
    const st = ST();
    if (!gs || !track.current) return;
    if (reduced()) return;

    const tween = gs.to(track.current, {
      xPercent: -50,
      duration: 26,
      ease: "none",
      repeat: -1,
    });

    let trigger: any = null;
    if (st) {
      trigger = st.create({
        trigger: track.current,
        start: "top bottom",
        end: "bottom top",
        onUpdate: (self: any) => {
          const v = self.getVelocity();
          const dir = v < 0 ? -1 : 1;
          const boost = Math.min(Math.abs(v) / 240, 7);
          gs.to(tween, {
            timeScale: dir * (1 + boost),
            duration: 0.5,
            ease: "power3.out",
            overwrite: true,
          });
          gs.to(tween, {
            timeScale: dir * 1,
            duration: 1.2,
            delay: 0.35,
            ease: "power3.out",
          });
        },
      });
    }

    return () => {
      tween.kill();
      if (trigger) trigger.kill();
    };
  }, []);

  return (
    <section
      data-jiro-section="marquee"
      data-jiro-label="Marquee"
      aria-hidden="true"
      className="relative overflow-hidden border-y border-bone/15 bg-ink py-5 text-bone md:py-7"
    >
      <div ref={track} className="flex w-max will-change-transform">
        <Strip />
        <Strip />
      </div>
    </section>
  );
}
