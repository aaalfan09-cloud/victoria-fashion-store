import { useEffect, useLayoutEffect, useRef } from "react";
import { g, ST, reduced } from "../lib/anim";
import { lookbook } from "../data/products";

export default function Lookbook() {
  const scroller = useRef<HTMLDivElement>(null);

  /* smooth fade + subtle scale reveal */
  useLayoutEffect(() => {
    const gs = g();
    const st = ST();
    const el = scroller.current;
    if (!gs || !st || !el || reduced()) return;

    const ctx = gs.context(() => {
      const frames = gs.utils.toArray("[data-look-frame]") as HTMLElement[];
      if (frames.length === 0) return;

      gs.fromTo(
        frames,
        { opacity: 0, scale: 1.04 },
        {
          opacity: 1,
          scale: 1,
          duration: 0.7,
          ease: "power2.out",
          stagger: 0.06,
          scrollTrigger: { trigger: el, start: "top 88%", once: true },
        }
      );
    }, scroller);

    return () => ctx.revert();
  }, []);

  /* drag-to-scroll + per-image parallax */
  useEffect(() => {
    const el = scroller.current;
    if (!el) return;
    let down = false;
    let startX = 0;
    let startLeft = 0;

    const parallax = () => {
      const imgs = el.querySelectorAll<HTMLElement>("[data-speed]");
      imgs.forEach((img) => {
        const speed = Number(img.dataset.speed || "0");
        img.style.transform = `translate3d(${el.scrollLeft * speed * -1}px,0,0) scale(1.12)`;
      });
    };

    const onDown = (e: MouseEvent) => {
      down = true;
      startX = e.pageX;
      startLeft = el.scrollLeft;
      el.classList.add("is-dragging");
    };
    const onMove = (e: MouseEvent) => {
      if (!down) return;
      e.preventDefault();
      el.scrollLeft = startLeft - (e.pageX - startX) * 1.15;
    };
    const onUp = () => {
      down = false;
      el.classList.remove("is-dragging");
    };

    el.addEventListener("mousedown", onDown);
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
    el.addEventListener("scroll", parallax, { passive: true });
    parallax();

    return () => {
      el.removeEventListener("mousedown", onDown);
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);
      el.removeEventListener("scroll", parallax);
    };
  }, []);

  return (
    <section
      data-jiro-section="lookbook"
      data-jiro-label="Lookbook"
      id="lookbook"
      className="relative overflow-hidden border-t border-bone/15 bg-ink py-20 md:py-32"
    >
      <div className="flex items-end justify-between px-5 pb-10 md:px-10 md:pb-16">
        <div>
          <p className="label text-bone/45">05 — Lookbook</p>
          <h2 className="mt-3 font-display text-[12vw] leading-[0.86] tracking-[-0.035em] text-bone md:text-[6vw]">
            Seventeen
            <span className="italic"> frames</span>
          </h2>
        </div>
        <p className="label hidden text-right text-bone/40 sm:block">
          Drag sideways
          <br />
          Photography — M. Rinaldi
        </p>
      </div>

      <div
        ref={scroller}
        className="no-scrollbar flex cursor-grab items-end gap-5 overflow-x-auto px-5 pb-4 active:cursor-grabbing md:gap-12 md:px-10"
      >
        {lookbook.map((l, i) => (
          <figure
            key={l.src}
            className={`shrink-0 ${l.w} ${i % 2 === 1 ? "mb-0" : "mb-10 md:mb-24"}`}
          >
            <div
              data-look-frame
              className={`relative w-full overflow-hidden bg-[#1a1a1a] ${l.h}`}
            >
              <img
                key={l.src}
                src={l.src}
                alt={`VICTORIA SS26 lookbook — ${l.cap}`}
                width={900}
                height={1200}
                loading="lazy"
                draggable={false}
                data-speed={l.speed}
                className="h-full w-full scale-110 object-cover will-change-transform"
              />
            </div>
            <figcaption className="mt-3 flex items-baseline justify-between gap-4">
              <span className="label text-bone/55">{l.cap}</span>
              <span className="label text-bone/30">
                {String(i + 1).padStart(2, "0")}
              </span>
            </figcaption>
          </figure>
        ))}
        <div className="h-px w-5 shrink-0 md:w-10" />
      </div>
    </section>
  );
}
