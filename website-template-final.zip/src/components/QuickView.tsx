import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { X } from "lucide-react";
import { g, money, reduced } from "../lib/anim";
import type { Product } from "../data/products";

export type QuickViewItem = {
  product: Product;
  image?: string;
  meta?: string;
};

const sizesFor = (p: Product | null): string[] => {
  if (!p) return [];
  if (p.category === "Bags") return ["One size"];
  if (p.category === "Footwear") return ["36", "37", "38", "39", "40", "41"];
  return ["34", "36", "38", "40", "42"];
};

export default function QuickView({
  item,
  onClose,
  onAdd,
  onCheckout,
}: {
  item: QuickViewItem | null;
  onClose: () => void;
  onAdd: (id: string, size: string) => void;
  onCheckout: (id: string, size: string) => void;
}) {
  const [shown, setShown] = useState<QuickViewItem | null>(null);
  const [size, setSize] = useState("");
  const [sizeError, setSizeError] = useState(false);

  const backdropRef = useRef<HTMLDivElement>(null);
  const panelRef = useRef<HTMLElement>(null);
  const imgWrapRef = useRef<HTMLDivElement>(null);
  const sizeRowRef = useRef<HTMLDivElement>(null);
  const initialized = useRef(false);

  useLayoutEffect(() => {
    if (initialized.current) return;
    initialized.current = true;
    const gs = g();
    if (gs && panelRef.current) {
      gs.set(panelRef.current, { xPercent: 100 });
    } else if (panelRef.current) {
      panelRef.current.style.transform = "translateX(100%)";
    }
  }, []);

  useEffect(() => {
    if (item) {
      setShown(item);
      setSize("");
      setSizeError(false);
    }
  }, [item]);

  useEffect(() => {
    const gs = g();
    const backdrop = backdropRef.current;
    const panel = panelRef.current;
    const imgWrap = imgWrapRef.current;
    if (!backdrop || !panel) return;

    const open = !!item;

    if (!gs || reduced()) {
      backdrop.style.opacity = open ? "1" : "0";
      backdrop.style.pointerEvents = open ? "auto" : "none";
      panel.style.transform = open ? "translateX(0%)" : "translateX(100%)";
      panel.style.pointerEvents = open ? "auto" : "none";
      if (imgWrap) {
        imgWrap.style.clipPath = "inset(0% 0% 0% 0%)";
      }
      return;
    }

    gs.killTweensOf([backdrop, panel, imgWrap].filter(Boolean));

    if (open) {
      backdrop.style.pointerEvents = "auto";
      panel.style.pointerEvents = "auto";
      gs.to(backdrop, {
        opacity: 1,
        duration: 0.6,
        ease: "power3.out",
      });
      gs.fromTo(
        panel,
        { xPercent: 100 },
        {
          xPercent: 0,
          duration: 0.9,
          ease: "expo.out",
        }
      );
      if (imgWrap) {
        gs.fromTo(
          imgWrap,
          { clipPath: "inset(0% 0% 100% 0%)" },
          {
            clipPath: "inset(0% 0% 0% 0%)",
            duration: 1.0,
            ease: "expo.out",
            delay: 0.15,
          }
        );
      }
    } else {
      gs.to(backdrop, {
        opacity: 0,
        duration: 0.5,
        ease: "power3.out",
        onComplete: () => {
          backdrop.style.pointerEvents = "none";
        },
      });
      gs.to(panel, {
        xPercent: 100,
        duration: 0.7,
        ease: "expo.out",
        onComplete: () => {
          panel.style.pointerEvents = "none";
        },
      });
    }
  }, [item]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape" && item) onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [item, onClose]);

  const requireSize = (): boolean => {
    if (size) return true;
    setSizeError(true);
    const gs = g();
    if (gs && sizeRowRef.current && !reduced()) {
      gs.fromTo(
        sizeRowRef.current,
        { x: -10 },
        {
          x: 0,
          duration: 0.55,
          ease: "elastic.out(1, 0.25)",
          clearProps: "x",
        }
      );
    }
    return false;
  };

  const open = !!item;
  const active = item ?? shown;
  const p = active?.product ?? null;
  const displayImage = active?.image ?? p?.image ?? "";
  const displayMeta = active?.meta ?? p?.meta ?? "SS26";

  return (
    <div
      data-jiro-section="quick-view"
      data-jiro-label="Quick View"
      aria-hidden={!open}
    >
      <div
        ref={backdropRef}
        onClick={onClose}
        className="pointer-events-none fixed inset-0 z-[115] bg-ink/70 opacity-0"
      />

      <aside
        ref={panelRef}
        role="dialog"
        aria-modal="true"
        aria-label="Product quick view"
        className="pointer-events-none fixed right-0 top-0 z-[116] flex h-[100svh] w-full flex-col bg-ink text-bone md:w-[480px]"
        style={{
          borderLeft: "1px solid rgba(237,232,223,0.18)",
        }}
      >
        <div className="flex items-center justify-between border-b border-bone/15 px-5 py-5 md:px-7">
          <span className="label text-bone/45">{displayMeta}</span>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close quick view"
            data-cursor="link"
            className="btn btn-ghost btn-sm"
          >
            <X className="h-3.5 w-3.5" aria-hidden="true" />
            Close
          </button>
        </div>

        {p && (
          <div className="flex-1 overflow-y-auto no-scrollbar">
            <div
              ref={imgWrapRef}
              className="relative aspect-[4/5] w-full overflow-hidden bg-bone"
              style={{ clipPath: "inset(0% 0% 100% 0%)" }}
            >
              <img
                key={displayImage}
                src={displayImage}
                alt={`${p.name} in ${p.material}`}
                width={1200}
                height={1500}
                loading="lazy"
                className="h-full w-full object-cover"
              />
              <span className="label absolute bottom-4 left-4 bg-ink/80 px-3 py-2 text-bone/80">
                {p.no} / {p.category}
              </span>
            </div>

            <div className="px-5 py-8 md:px-7">
              <h2 className="font-display text-[2.4rem] leading-[1.02] tracking-[-0.02em]">
                {p.name}
              </h2>
              <p className="label mt-3 text-bone/45">{p.material}</p>
              <p className="mt-6 max-w-[42ch] text-[0.95rem] leading-relaxed text-bone/70">
                {p.note}
              </p>

              <div className="mt-9 border-t border-bone/15 pt-6">
                <div className="flex items-center justify-between gap-4">
                  <p className="label text-bone/45">Size</p>
                  {sizeError && (
                    <span
                      role="alert"
                      className="label text-[#e28585]"
                    >
                      Select a size
                    </span>
                  )}
                </div>
                <div ref={sizeRowRef} className="mt-4 flex flex-wrap gap-3">
                  {sizesFor(p).map((s) => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => {
                        setSize(s);
                        setSizeError(false);
                      }}
                      data-cursor="link"
                      className={`btn btn-sm ${
                        size === s ? "btn-solid" : "btn-ghost"
                      }`}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>

              <dl className="mt-9 grid grid-cols-2 gap-y-4 border-t border-bone/15 pt-6">
                <dt className="label text-bone/40">Atelier</dt>
                <dd className="label text-right text-bone/75">Firenze</dd>
                <dt className="label text-bone/40">Lead time</dt>
                <dd className="label text-right text-bone/75">4 weeks</dd>
                <dt className="label text-bone/40">Edition</dt>
                <dd className="label text-right text-bone/75">Limited, 40</dd>
              </dl>
            </div>
          </div>
        )}

        <div className="flex flex-col gap-4 border-t border-bone/15 px-5 py-5 sm:flex-row sm:items-center sm:justify-between md:px-7">
          <span className="font-display text-2xl">{p ? money(p.price) : ""}</span>
          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => {
                if (!p || !requireSize()) return;
                onAdd(p.id, size);
                onClose();
              }}
              data-cursor="link"
              data-magnetic
              className="btn btn-solid"
            >
              Add to bag +
            </button>
            <button
              type="button"
              onClick={() => {
                if (!p || !requireSize()) return;
                onCheckout(p.id, size);
                onClose();
              }}
              data-cursor="link"
              className="btn btn-ghost"
            >
              Checkout
            </button>
          </div>
        </div>
      </aside>
    </div>
  );
}
