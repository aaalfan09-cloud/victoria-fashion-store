import { Fragment, useLayoutEffect, useRef } from "react";
import { g, ST, reduced } from "../lib/anim";

const TEXT =
  "We make fewer things, slower. A coat is cut once, fitted sixteen times, and finished by the same pair of hands that opened the cloth. Nothing is shouted. The label sits inside the seam, where only you will find it.";

const WORDS = TEXT.split(" ");

export default function Manifesto() {
  const root = useRef<HTMLElement>(null);

  useLayoutEffect(() => {
    const gs = g();
    const st = ST();
    const el = root.current;
    if (!el) return;

    const words = el.querySelectorAll<HTMLElement>("[data-word]");

    if (!gs || !st || reduced()) {
      words.forEach((w) => {
        w.style.opacity = "1";
        w.style.transform = "none";
      });
      return;
    }

    const ctx = gs.context(() => {
      gs.fromTo(
        words,
        { opacity: 0, yPercent: 100 },
        {
          opacity: 1,
          yPercent: 0,
          duration: 0.5,
          ease: "power2.out",
          stagger: { each: 0.008, from: "start" },
          overwrite: "auto",
          scrollTrigger: {
            trigger: el,
            start: "top 85%",
            once: true,
          },
        }
      );
    }, el);
    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={root}
      data-jiro-section="manifesto"
      data-jiro-label="Manifesto"
      className="relative bg-ink px-5 pb-10 pt-20 md:px-10 md:py-40"
    >
      <div className="grid grid-cols-12 gap-y-10">
        <div className="col-span-12 md:col-span-3">
          <p className="label text-bone/70">01 — Manifesto</p>
          <p className="label mt-4 text-bone/70">
            On restraint
            <br />
            and the long seam
          </p>
        </div>

        <h2 className="col-span-12 font-display text-[2rem] leading-[1.18] tracking-[-0.015em] text-bone md:col-span-8 md:col-start-5 md:text-[3.4rem] md:leading-[1.12]">
          {WORDS.map((w, i) => (
            <Fragment key={i}>
              <span className="inline-block overflow-hidden py-[0.06em] -my-[0.06em] align-baseline">
                <span data-word className="inline-block will-change-transform">
                  {w}
                </span>
              </span>
              {i < WORDS.length - 1 ? " " : ""}
            </Fragment>
          ))}
        </h2>

        <div className="col-span-12 mt-6 flex flex-col gap-4 border-t border-bone/20 pt-6 sm:flex-row sm:items-center sm:justify-between md:col-span-8 md:col-start-5">
          <p className="label text-bone/70">Victoria Lamberti — Creative Director</p>
          <p className="label text-bone/70">Firenze, MMXXVI</p>
        </div>
      </div>
    </section>
  );
}
