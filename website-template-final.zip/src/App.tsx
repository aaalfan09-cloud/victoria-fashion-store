import { useCallback, useEffect, useState } from "react";
import Preloader from "./components/Preloader";
import Cursor from "./components/Cursor";
import Header from "./components/Header";
import Hero from "./components/Hero";
import Marquee from "./components/Marquee";
import Manifesto from "./components/Manifesto";
import Runway from "./components/Runway";
import Collection from "./components/Collection";
import QuickView, { type QuickViewItem } from "./components/QuickView";
import Atelier from "./components/Atelier";
import Lookbook from "./components/Lookbook";
import FooterNewsletter from "./components/FooterNewsletter";
import BagDrawer from "./components/BagDrawer";
import { products, type RunwayLook } from "./data/products";
import { g, ST, FlipLib, LenisLib, reduced } from "./lib/anim";

export type BagLine = { id: string; size: string; qty: number };

export default function App() {
  const [loaded, setLoaded] = useState(false);
  const [bag, setBag] = useState<BagLine[]>([]);
  const [bagOpen, setBagOpen] = useState(false);
  const [scrollToCheckoutKey, setScrollToCheckoutKey] = useState(0);
  const [quickView, setQuickView] = useState<QuickViewItem | null>(null);

  /* ---- smooth scroll + plugin wiring ---- */
  useEffect(() => {
    const gs = g();
    const st = ST();
    const flip = FlipLib();
    if (!gs || !st) return;
    gs.registerPlugin(st, flip);

    let raf: ((t: number) => void) | null = null;
    let lenis: any = null;
    const Lenis = LenisLib();

    if (!reduced() && Lenis) {
      lenis = new Lenis({ lerp: 0.1, smoothWheel: true, wheelMultiplier: 1 });
      (window as any).__lenis = lenis;
      lenis.on("scroll", st.update);
      raf = (time: number) => lenis.raf(time * 1000);
      gs.ticker.add(raf);
      gs.ticker.lagSmoothing(0);
      lenis.stop();
    }

    const refresh = () => st.refresh();
    window.addEventListener("load", refresh);
    const t1 = window.setTimeout(refresh, 900);
    const t2 = window.setTimeout(refresh, 2600);

    return () => {
      window.removeEventListener("load", refresh);
      window.clearTimeout(t1);
      window.clearTimeout(t2);
      if (raf) gs.ticker.remove(raf);
      if (lenis) lenis.destroy();
      (window as any).__lenis = null;
    };
  }, []);

  /* ---- release the scroll lock when the preloader is done ---- */
  useEffect(() => {
    const lenis = (window as any).__lenis;
    if (loaded) {
      document.body.classList.remove("is-locked");
      if (lenis) lenis.start();
      const st = ST();
      if (st) window.setTimeout(() => st.refresh(), 300);
    } else {
      document.body.classList.add("is-locked");
    }
  }, [loaded]);

  /* ---- lock scroll while a panel is open ---- */
  useEffect(() => {
    if (!loaded) return;
    const lenis = (window as any).__lenis;
    const locked = bagOpen || Boolean(quickView);
    if (locked) {
      if (lenis) lenis.stop();
      document.documentElement.style.overflow = "hidden";
    } else {
      document.documentElement.style.overflow = "";
      if (lenis) lenis.start();
    }
    return () => {
      document.documentElement.style.overflow = "";
    };
  }, [bagOpen, quickView, loaded]);

  const addToBag = useCallback((id: string, size = "38") => {
    setBag((prev) => {
      const found = prev.find((l) => l.id === id && l.size === size);
      if (found)
        return prev.map((l) =>
          l.id === id && l.size === size ? { ...l, qty: l.qty + 1 } : l
        );
      return [...prev, { id, size, qty: 1 }];
    });
    setBagOpen(true);
  }, []);

  const checkoutWithItem = useCallback((id: string, size: string) => {
    setBag((prev) => {
      const found = prev.find((l) => l.id === id && l.size === size);
      if (found) return prev;
      return [...prev, { id, size, qty: 1 }];
    });
    setScrollToCheckoutKey((k) => k + 1);
    setBagOpen(true);
  }, []);

  const handleSelectLook = useCallback((look: RunwayLook) => {
    const product = products.find((p) => p.id === look.productId);
    if (!product) return;
    setQuickView({
      product,
      image: look.src,
      meta: `SS26 — Look ${look.no}`,
    });
  }, []);

  const setQty = useCallback((id: string, size: string, delta: number) => {
    setBag((prev) =>
      prev
        .map((l) =>
          l.id === id && l.size === size ? { ...l, qty: l.qty + delta } : l
        )
        .filter((l) => l.qty > 0)
    );
  }, []);

  const removeLine = useCallback((id: string, size: string) => {
    setBag((prev) => prev.filter((l) => !(l.id === id && l.size === size)));
  }, []);

  const count = bag.reduce((n, l) => n + l.qty, 0);

  return (
    <div className="relative bg-ink text-bone font-sans antialiased">
      <Preloader onDone={() => setLoaded(true)} />
      <Cursor />
      <Header count={count} onBag={() => setBagOpen(true)} visible={loaded} />

      <main id="top">
        <Hero ready={loaded} />
        <Marquee />
        <Manifesto />
        <Runway
          paused={Boolean(quickView || bagOpen)}
          onSelectLook={handleSelectLook}
        />
        <Collection
          onQuickView={(p) => setQuickView({ product: p })}
          onAdd={(id) => addToBag(id)}
        />
        <Atelier />
        <Lookbook />
      </main>

      <FooterNewsletter />

      <QuickView
        item={quickView}
        onClose={() => setQuickView(null)}
        onAdd={addToBag}
        onCheckout={checkoutWithItem}
      />

      <BagDrawer
        open={bagOpen}
        bag={bag}
        products={products}
        scrollToCheckoutKey={scrollToCheckoutKey}
        onClose={() => setBagOpen(false)}
        onQty={setQty}
        onRemove={removeLine}
      />
    </div>
  );
}
